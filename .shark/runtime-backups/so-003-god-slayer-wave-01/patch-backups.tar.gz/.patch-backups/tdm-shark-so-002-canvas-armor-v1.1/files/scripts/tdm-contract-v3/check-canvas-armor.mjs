#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const failures = [];
const requiredFiles = [
  'src/app/canvas/page.tsx',
  'src/app/canvas/loading.tsx',
  'src/app/canvas/error.tsx',
  'src/app/canvas/resultado/page.tsx',
  'src/features/theory-of-change/canvas/ui/canvas-workspace/canvas-workspace.e2e.ts',
  'src/features/theory-of-change/canvas/domain/canvas-element-id.test.ts',
  'scripts/tdm-contract-v3/check-canvas-continuity.mjs',
  'scripts/tdm-contract-v3/check-canvas-stability-wave03.mjs'
];

const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');
const assert = (condition, message) => { if (!condition) failures.push(message); };

for (const file of requiredFiles) {
  assert(fs.existsSync(path.join(root, file)), `arquivo de armadura ausente: ${file}`);
}

if (fs.existsSync(path.join(root, 'src/app/canvas/error.tsx'))) {
  const source = read('src/app/canvas/error.tsx');
  assert(source.includes("'use client'"), 'boundary de erro do Canvas deve ser client component');
  assert(source.includes('TdmRouteError'), 'boundary de erro do Canvas deve usar o estado oficial');
}

if (fs.existsSync(path.join(root, 'src/features/theory-of-change/canvas/domain/canvas-element-id.test.ts'))) {
  const source = read('src/features/theory-of-change/canvas/domain/canvas-element-id.test.ts');
  assert(source.includes('ignora colisões vindas de um projeto hidratado'), 'teste de colisão hidratada foi removido');
  assert(source.includes('esgota tentativas'), 'teste de falha segura da fábrica de IDs foi removido');
}

if (fs.existsSync(path.join(root, 'src/features/theory-of-change/canvas/ui/canvas-workspace/canvas-workspace.e2e.ts'))) {
  const source = read('src/features/theory-of-change/canvas/ui/canvas-workspace/canvas-workspace.e2e.ts');
  for (const proof of [
    "page.goto('/canvas')",
    'Alterações salvas automaticamente.',
    'page.reload()',
    "page.getByRole('button', { name: 'Visualizar resultado' })",
    "toHaveURL(/\\/canvas\\/resultado$/)"
  ]) assert(source.includes(proof), `E2E do Canvas não contém prova obrigatória: ${proof}`);
}

const pkg = JSON.parse(read('package.json'));
assert(pkg.scripts?.['check:tdm:canvas-armor'], 'script check:tdm:canvas-armor não registrado');
assert(pkg.scripts?.['test:e2e:canvas'], 'script test:e2e:canvas não registrado');

const gates = JSON.parse(read('.sharkops/policy/gates.json'));
const preCommit = gates.profiles?.[gates.activeProfile]?.mandatory?.['pre-commit'] ?? [];
const prePush = gates.profiles?.[gates.activeProfile]?.mandatory?.['pre-push'] ?? [];
assert(preCommit.includes('check:tdm:canvas-armor'), 'Canvas Armor não bloqueia pre-commit');
assert(prePush.includes('test:e2e:canvas'), 'E2E do Canvas não bloqueia pre-push');

if (failures.length) {
  console.error('\nTDM CANVAS ARMOR: FAIL\n');
  failures.forEach((failure, index) => console.error(`${index + 1}. ${failure}.`));
  process.exit(1);
}

console.log('PASS: rotas, erro, IDs hidratados, autosave, recarga e resultado estão sob armadura executável.');
