# SO-002 | Canvas Armor

Status: ACTIVE

Esta mordida instala a primeira armadura executável do Canvas antes de qualquer decomposição estrutural.

## Proteções introduzidas

- contrato estático para `/canvas` e `/canvas/resultado`;
- boundary de erro da família de rotas do Canvas;
- prova explícita contra colisão de IDs hidratados;
- preservação do teste E2E de autosave, recarga e resultado;
- gate obrigatório no pre-commit;
- E2E do Canvas obrigatório no pre-push.

## Fora desta revisão

- decomposição de God files;
- alteração visual;
- mudança da regra causal;
- troca de repository, MSW ou React Flow.
