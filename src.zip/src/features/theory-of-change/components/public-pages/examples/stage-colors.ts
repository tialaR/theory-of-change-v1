import type { TdmStage } from '../../../domain/tdm-stages';

export const EXAMPLE_STAGE_COLORS: Record<
  TdmStage,
  { accent: string; border: string; glow: string; soft: string }
> = {
  input: {
    accent: 'rgba(167, 139, 250, 0.92)',
    border: 'rgba(167, 139, 250, 0.38)',
    glow: 'rgba(167, 139, 250, 0.22)',
    soft: 'rgba(167, 139, 250, 0.1)'
  },
  activity: {
    accent: 'rgba(96, 165, 250, 0.92)',
    border: 'rgba(96, 165, 250, 0.38)',
    glow: 'rgba(96, 165, 250, 0.22)',
    soft: 'rgba(96, 165, 250, 0.1)'
  },
  output: {
    accent: 'rgba(245, 158, 66, 0.9)',
    border: 'rgba(245, 158, 66, 0.38)',
    glow: 'rgba(245, 158, 66, 0.22)',
    soft: 'rgba(245, 158, 66, 0.1)'
  },
  outcome: {
    accent: 'rgba(72, 211, 165, 0.9)',
    border: 'rgba(72, 211, 165, 0.38)',
    glow: 'rgba(72, 211, 165, 0.22)',
    soft: 'rgba(72, 211, 165, 0.1)'
  }
};

export const EXAMPLE_STAGE_LABELS: Record<TdmStage, string> = {
  input: 'Insumos',
  activity: 'Atividades',
  output: 'Produtos',
  outcome: 'Resultados'
};
