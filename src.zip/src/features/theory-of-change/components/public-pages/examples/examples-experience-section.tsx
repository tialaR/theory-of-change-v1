'use client';

import { ConnectedResultPreview } from './connected-result-preview';
import { ExperienceCard, FlowIcon, ResultIcon } from './experience-card';
import { FlowPreview } from './flow-preview';
import styles from './examples.module.sass';

export function ExamplesExperienceSection() {
  return (
    <div className={styles.experienceGrid}>
      <ExperienceCard
        href="/exemplos/fluxo"
        icon={<FlowIcon />}
        title="Visualização do fluxo"
        description="Entenda como insumos, atividades, produtos e resultados se conectam antes de abrir a experiência completa."
        preview={<FlowPreview />}
        delay={0}
      />
      <ExperienceCard
        href="/exemplos/resultado"
        icon={<ResultIcon />}
        title="Resultado conectado"
        description="Veja a teoria organizada com relações, riscos, hipóteses e leitura visual do caminho causal."
        preview={<ConnectedResultPreview />}
        delay={0.06}
      />
    </div>
  );
}
