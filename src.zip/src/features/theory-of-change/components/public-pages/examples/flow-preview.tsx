'use client';

import { motion, useReducedMotion } from 'motion/react';
import { useState, type CSSProperties } from 'react';
import styles from './examples.module.sass';

const FLOW_COLUMNS = [
  { stage: 'input' as const, count: 3 },
  { stage: 'activity' as const, count: 2 },
  { stage: 'output' as const, count: 2 },
  { stage: 'outcome' as const, count: 1 }
] as const;

const FLOW_PATHS = [
  {
    id: 'c1t-c2t',
    d: 'M 94 24 C 100 24, 104 24, 110 24',
    stroke: 'rgba(167, 139, 250, 0.44)',
    node: { cx: 102, cy: 24, fill: 'rgba(245, 158, 66, 0.58)' }
  },
  {
    id: 'c1m-c2t',
    d: 'M 94 60 C 100 48, 104 32, 110 24',
    stroke: 'rgba(167, 139, 250, 0.4)'
  },
  {
    id: 'c1b-c2m',
    d: 'M 94 96 C 100 84, 104 68, 110 60',
    stroke: 'rgba(167, 139, 250, 0.4)'
  },
  {
    id: 'c2t-c3t',
    d: 'M 192 24 C 198 24, 202 24, 208 24',
    stroke: 'rgba(96, 165, 250, 0.44)',
    node: { cx: 200, cy: 24, fill: 'rgba(245, 158, 66, 0.58)' }
  },
  {
    id: 'c2m-c3m',
    d: 'M 192 60 C 198 60, 202 60, 208 60',
    stroke: 'rgba(96, 165, 250, 0.4)'
  },
  {
    id: 'c3t-c4',
    d: 'M 290 24 C 296 24, 300 36, 306 42',
    stroke: 'rgba(245, 158, 66, 0.38)'
  },
  {
    id: 'c3m-c4',
    d: 'M 290 60 C 296 60, 300 48, 306 42',
    stroke: 'rgba(72, 211, 165, 0.4)',
    node: { cx: 298, cy: 42, fill: 'rgba(72, 211, 165, 0.55)' }
  }
] as const;

const SUBTLE_STAGE_COLORS = {
  input: {
    accent: 'rgba(167, 139, 250, 0.55)',
    border: 'rgba(167, 139, 250, 0.18)',
    glow: 'rgba(167, 139, 250, 0.08)',
    edge: 'rgba(167, 139, 250, 0.35)'
  },
  activity: {
    accent: 'rgba(96, 165, 250, 0.55)',
    border: 'rgba(96, 165, 250, 0.18)',
    glow: 'rgba(96, 165, 250, 0.08)',
    edge: 'rgba(96, 165, 250, 0.35)'
  },
  output: {
    accent: 'rgba(245, 158, 66, 0.5)',
    border: 'rgba(245, 158, 66, 0.18)',
    glow: 'rgba(245, 158, 66, 0.08)',
    edge: 'rgba(245, 158, 66, 0.32)'
  },
  outcome: {
    accent: 'rgba(72, 211, 165, 0.5)',
    border: 'rgba(72, 211, 165, 0.18)',
    glow: 'rgba(72, 211, 165, 0.08)',
    edge: 'rgba(72, 211, 165, 0.32)'
  }
} as const;

type FlowPreviewProps = {
  expanded?: boolean;
};

export function FlowPreview({ expanded = false }: FlowPreviewProps) {
  const reduced = useReducedMotion();
  const [hovered, setHovered] = useState(false);

  return (
    <div
      className={`${styles.previewStage} ${expanded ? styles.previewStage_expanded : ''} ${styles.flowDraft}`}
      aria-hidden="true"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div className={styles.previewGridBg} />
      <div className={styles.flowDraftCanvas}>
        <svg className={styles.flowDraftSvg} viewBox="0 0 400 120" preserveAspectRatio="none">
        <defs>
          <marker id="flow-draft-arrow" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
            <path d="M0,0 L6,3 L0,6 Z" fill="rgba(244,244,245,0.42)" />
          </marker>
        </defs>
        {FLOW_PATHS.map((path, index) => (
          <g key={path.id}>
            <motion.path
              className={styles.flowDraftPath}
              d={path.d}
              fill="none"
              stroke={path.stroke}
              strokeWidth="1.25"
              strokeDasharray="3.5 4.5"
              strokeLinecap="round"
              markerEnd="url(#flow-draft-arrow)"
              initial={{ pathLength: reduced ? 1 : 0.85, opacity: reduced ? 0.45 : 0.28 }}
              animate={{
                pathLength: 1,
                opacity: hovered && !reduced ? 0.62 : 0.34,
                strokeDashoffset: hovered && !reduced ? [16, 0] : 0
              }}
              transition={{
                pathLength: { duration: reduced ? 0 : 0.7, delay: index * 0.05, ease: 'easeOut' },
                opacity: { duration: 0.28, ease: 'easeOut' },
                strokeDashoffset: {
                  duration: 1.4,
                  repeat: hovered && !reduced ? Infinity : 0,
                  ease: 'linear'
                }
              }}
            />
            {'node' in path && path.node ? (
              <motion.circle
                cx={path.node.cx}
                cy={path.node.cy}
                r="3"
                fill={path.node.fill}
                stroke="rgba(12, 12, 13, 0.85)"
                strokeWidth="0.75"
                initial={{ opacity: reduced ? 0.6 : 0 }}
                animate={{ opacity: hovered && !reduced ? 0.85 : 0.55 }}
                transition={{ duration: 0.28 }}
              />
            ) : null}
          </g>
        ))}
      </svg>
      <div className={styles.flowDraftGrid}>
        {FLOW_COLUMNS.map((column) => {
          const colors = SUBTLE_STAGE_COLORS[column.stage];

          return (
            <div
              key={column.stage}
              className={`${styles.flowDraftColumn} ${column.count === 1 ? styles.flowDraftColumn_final : ''} ${column.count === 2 ? styles.flowDraftColumn_pair : ''}`}
              style={
                {
                  '--stage-accent': colors.accent,
                  '--stage-border': colors.border,
                  '--stage-glow': colors.glow,
                  '--stage-edge': colors.edge
                } as CSSProperties
              }
            >
              {Array.from({ length: column.count }).map((_, cardIndex) => (
                <div key={`${column.stage}-${cardIndex}`} className={styles.flowDraftCard}>
                  <span className={styles.flowDraftCardEdge} aria-hidden="true" />
                </div>
              ))}
            </div>
          );
        })}
      </div>
      </div>
    </div>
  );
}
