'use client';

import Link from 'next/link';
import { motion, useReducedMotion } from 'motion/react';
import type { ReactNode } from 'react';
import styles from './examples.module.sass';

type ExperienceCardProps = {
  href: string;
  icon: ReactNode;
  title: string;
  description: string;
  preview: ReactNode;
  delay?: number;
};

export function ExperienceCard({
  href,
  icon,
  title,
  description,
  preview,
  delay = 0
}: ExperienceCardProps) {
  const reduced = useReducedMotion();

  return (
    <motion.div
      initial={{ opacity: reduced ? 1 : 0, y: reduced ? 0 : '1rem' }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: reduced ? 0 : 0.5, delay, ease: [0.22, 1, 0.36, 1] }}
      whileHover={reduced ? undefined : { y: '-0.3rem' }}
    >
      <Link href={href} className={styles.experienceCard}>
        <div className={styles.experienceCardHeader}>
          <span className={styles.experienceIcon}>{icon}</span>
          <div className={styles.experienceCopy}>
            <h3>{title}</h3>
            <p>{description}</p>
          </div>
        </div>
        <div className={styles.experiencePreview}>{preview}</div>
        <span className={styles.experienceCta}>
          Abrir
          <svg viewBox="0 0 16 16" fill="none" aria-hidden="true">
            <path
              d="M3.5 8h8.25M8.75 4.75 12 8l-3.25 3.25"
              stroke="currentColor"
              strokeWidth="1.35"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </span>
      </Link>
    </motion.div>
  );
}

function FlowIcon() {
  return (
    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <rect x="2.5" y="5" width="4.5" height="4.5" rx="0.75" stroke="currentColor" strokeWidth="1.25" />
      <rect x="7.75" y="10.5" width="4.5" height="4.5" rx="0.75" stroke="currentColor" strokeWidth="1.25" />
      <rect x="13" y="5" width="4.5" height="4.5" rx="0.75" stroke="currentColor" strokeWidth="1.25" />
      <path
        d="M7 7.25h1.25M11.75 12.75H13M11.75 7.25h1.25"
        stroke="currentColor"
        strokeWidth="1.1"
        strokeLinecap="round"
      />
    </svg>
  );
}

function ResultIcon() {
  return (
    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <rect x="3" y="4" width="14" height="12" rx="1.25" stroke="currentColor" strokeWidth="1.25" />
      <path d="M6.5 8h7M6.5 10.75h4.5M6.5 13.5h5.5" stroke="currentColor" strokeWidth="1.1" strokeLinecap="round" />
      <circle cx="14.25" cy="6.25" r="1.75" stroke="currentColor" strokeWidth="1.1" />
    </svg>
  );
}

export { FlowIcon, ResultIcon };
