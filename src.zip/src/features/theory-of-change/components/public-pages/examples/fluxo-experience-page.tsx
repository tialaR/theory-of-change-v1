'use client';

import Link from 'next/link';
import {
  PublicButton,
  PublicFooter,
  PublicHeader,
  PublicHero,
  PublicSection,
  PublicShell
} from '@/shared/ui/lusion-resend-ds';
import { ConnectedResultPreview } from './connected-result-preview';
import { FlowPreview } from './flow-preview';
import styles from './examples.module.sass';

export function FluxoExperiencePage() {
  return (
    <PublicShell>
      <PublicHeader />
      <PublicHero
        compact
        kicker="Fluxo da teoria"
        title="Veja como as etapas se conectam."
        description="Uma leitura visual do caminho causal — insumos, atividades, produtos e resultados em sequência."
        actions={
          <>
            <PublicButton href="/exemplos/resultado">Ver resultado</PublicButton>
            <PublicButton href="/exemplos" variant="ghost">
              Voltar aos exemplos
            </PublicButton>
          </>
        }
      />
      <PublicSection compact title="Caminho causal" description="Cada etapa alimenta a próxima até o resultado esperado.">
        <div className={styles.fluxoExpanded}>
          <FlowPreview expanded />
        </div>
      </PublicSection>
      <PublicSection compact title="Resultado conectado" description="Explore relações, riscos e hipóteses na leitura completa.">
        <div className={styles.fluxoExpanded}>
          <ConnectedResultPreview expanded />
        </div>
        <div className={styles.fluxoActions}>
          <PublicButton href="/exemplos/resultado">Abrir resultado</PublicButton>
          <Link href="/exemplos" className={styles.fluxoBackLink}>
            Voltar
          </Link>
        </div>
      </PublicSection>
      <PublicFooter />
    </PublicShell>
  );
}
