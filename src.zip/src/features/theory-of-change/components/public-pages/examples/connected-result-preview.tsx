'use client';

import { motion, useReducedMotion } from 'motion/react';
import type { CSSProperties } from 'react';
import { EXAMPLE_STAGE_COLORS, EXAMPLE_STAGE_LABELS } from './stage-colors';
import styles from './examples.module.sass';

const COLUMNS = [
  { stage: 'input' as const, items: 2 },
  { stage: 'activity' as const, items: 2 },
  { stage: 'output' as const, items: 1 },
  { stage: 'outcome' as const, items: 1 }
] as const;

const EDGE_PATHS = [
  { d: 'M 118 52 C 142 52, 152 38, 176 38', badge: 'R' as const, badgeX: 147, badgeY: 45 },
  { d: 'M 118 72 C 142 72, 152 58, 176 58', badge: null, badgeX: 0, badgeY: 0 },
  { d: 'M 248 46 C 272 46, 282 52, 306 52', badge: 'R' as const, badgeX: 277, badgeY: 49 },
  { d: 'M 248 62 C 272 62, 282 58, 306 58', badge: null, badgeX: 0, badgeY: 0 },
  { d: 'M 358 54 C 382 54, 392 54, 416 54', badge: 'H' as const, badgeX: 387, badgeY: 54 }
] as const;

type ConnectedResultPreviewProps = {
  expanded?: boolean;
};

export function ConnectedResultPreview({ expanded = false }: ConnectedResultPreviewProps) {
  const reduced = useReducedMotion();

  return (
    <div
      className={`${styles.previewStage} ${expanded ? styles.previewStage_expanded : ''}`}
      aria-hidden="true"
    >
      <div className={styles.previewGridBg} />
      <svg className={styles.previewSvg} viewBox="0 0 480 108" preserveAspectRatio="xMidYMid meet">
        <defs>
          <marker id="result-arrow" markerWidth="7" markerHeight="7" refX="5" refY="3.5" orient="auto">
            <path d="M0,0 L7,3.5 L0,7 Z" fill="rgba(244,244,245,0.45)" />
          </marker>
        </defs>
        {EDGE_PATHS.map((edge, index) => (
          <g key={edge.d}>
            <motion.path
              d={edge.d}
              fill="none"
              stroke="rgba(244,244,245,0.22)"
              strokeWidth="1.25"
              strokeDasharray="3 4"
              markerEnd="url(#result-arrow)"
              initial={{ pathLength: reduced ? 1 : 0, opacity: reduced ? 0.5 : 0.15 }}
              animate={{
                pathLength: 1,
                opacity: [0.3, 0.65, 0.3],
                strokeDashoffset: reduced ? 0 : [0, -14]
              }}
              transition={{
                pathLength: { duration: reduced ? 0 : 0.9, delay: index * 0.1 },
                opacity: { duration: reduced ? 0 : 3.4, repeat: reduced ? 0 : Infinity, ease: 'easeInOut' },
                strokeDashoffset: { duration: reduced ? 0 : 2.6, repeat: reduced ? 0 : Infinity, ease: 'linear' }
              }}
            />
            {edge.badge ? (
              <motion.g
                initial={{ opacity: reduced ? 1 : 0, scale: reduced ? 1 : 0.7 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: reduced ? 0 : 0.35, delay: 0.4 + index * 0.08 }}
              >
                <circle
                  cx={edge.badgeX}
                  cy={edge.badgeY}
                  r="7"
                  className={edge.badge === 'R' ? styles.badgeRisk : styles.badgeHypothesis}
                />
                <text x={edge.badgeX} y={edge.badgeY + 3} className={styles.badgeText}>
                  {edge.badge}
                </text>
              </motion.g>
            ) : null}
          </g>
        ))}
      </svg>
      <div className={styles.resultColumns}>
        {COLUMNS.map((column, columnIndex) => {
          const colors = EXAMPLE_STAGE_COLORS[column.stage];
          return (
            <motion.div
              key={column.stage}
              className={styles.resultColumn}
              style={
                {
                  '--stage-accent': colors.accent,
                  '--stage-border': colors.border,
                  '--stage-soft': colors.soft
                } as CSSProperties
              }
              initial={{ opacity: reduced ? 1 : 0, y: reduced ? 0 : '0.625rem' }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: reduced ? 0 : 0.45, delay: columnIndex * 0.07 }}
            >
              <span className={styles.resultColumnLabel}>{EXAMPLE_STAGE_LABELS[column.stage]}</span>
              <div className={styles.resultItems}>
                {Array.from({ length: column.items }).map((_, itemIndex) => (
                  <motion.span
                    key={`${column.stage}-${itemIndex}`}
                    className={styles.resultItem}
                    initial={{ opacity: reduced ? 1 : 0, scale: reduced ? 1 : 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{
                      duration: reduced ? 0 : 0.35,
                      delay: columnIndex * 0.07 + itemIndex * 0.06
                    }}
                  />
                ))}
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
